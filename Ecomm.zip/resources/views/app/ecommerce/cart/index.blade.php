@extends('layouts.master')

@section('title')Cart
 {{ $title }}
@endsection

@push('css')
@endpush

@section('content')
	@component('components.breadcrumb')
		@slot('breadcrumb_title')
			<h3>Cart</h3>
		@endslot
		<li class="breadcrumb-item">Ecommerce</li>
		<li class="breadcrumb-item active">Cart</li>
	@endcomponent
	
	@livewire('ecommerce.cart')
	
	@push('scripts')
	<script src="{{asset('assets/js/touchspin/vendors.min.js')}}"></script>
    <script src="{{asset('assets/js/touchspin/touchspin.js')}}"></script>
    <script src="{{asset('assets/js/touchspin/input-groups.min.js')}}"></script>
	<script src="{{asset('assets/js/sweet-alert2/sweetalert.all.min.js')}}"></script>

	@if(session()->has('success'))
		<script>
			Swal.fire(
				'Added to cart!',
				'{{ session()->get("success") }}',
				'success'
			)
		</script>
	@endif
	@endpush

@endsection
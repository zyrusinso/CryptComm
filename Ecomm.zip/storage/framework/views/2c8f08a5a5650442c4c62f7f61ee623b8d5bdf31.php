<div class="py-3">
    <hr />
</div>
<?php /**PATH G:\xampp\htdocs\Laravel\E-comm2\resources\views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>
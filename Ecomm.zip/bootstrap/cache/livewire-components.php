<?php return array (
  'ecommerce.cart' => 'App\\Http\\Livewire\\Ecommerce\\Cart',
  'ecommerce.product' => 'App\\Http\\Livewire\\Ecommerce\\Product',
  'product' => 'App\\Http\\Livewire\\Product',
);
<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH G:\xampp\htdocs\Laravel\E-comm2\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>
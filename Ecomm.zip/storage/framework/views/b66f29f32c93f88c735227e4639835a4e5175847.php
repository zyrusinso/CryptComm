<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-outline-secondary text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH G:\xampp\htdocs\Laravel\E-comm2\resources\views/vendor/jetstream/components/secondary-button.blade.php ENDPATH**/ ?>
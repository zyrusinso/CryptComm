<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH G:\xampp\htdocs\Laravel\Ecomm\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Livewire\Ecommerce;

use Livewire\Component;
use App\Models\Ecommerce\Cart;
use Vinkla\Hashids\Facades\Hashids;
use Shakurov\Coinbase\Facades\Coinbase;
use App\Models\Ecommerce\Product as ProductModel;

class Product extends Component
{
    public $quantity = 1;

    public $title;
    public $description;
    public $price;

    // protected $rules = [
    //     'title' => 'required|min:6',
    //     'description' => 'required',
    //     'price' => 'required',
    // ];

    public function submitCustom()
    {
        // $this->validate();


    }

    public function quantityUp()
    {
        $this->quantity++;
    }

    public function quantityDown()
    {
        if($this->quantity != 1){
            $this->quantity--;
        }
    }

    public function addToCart($id)
    {
        $currentCart = Cart::where('product_id', $id)->where('user_id', auth()->id())->first();

        $data = [
            'product_id' => $id,
            'user_id' => auth()->id(),
            'quantity' => ($currentCart)? $currentCart->quantity+$this->quantity : $this->quantity
        ];

        Cart::updateOrCreate(['product_id' => $id, 'user_id' => auth()->id() ], $data);

        return redirect(route('cart.index'))->with('success', 'Successfully Added to Cart!');
    }
    
    public function resetQuantity()
    {
        $this->resetValidation();
        $this->quantity = 1;
    }

    public function render()
    {
        $products = Coinbase::getCheckouts()['data'];
        // $products = ProductModel::all();
        // dd($products);

        return view('livewire.ecommerce.product', compact('products'));
    }
}

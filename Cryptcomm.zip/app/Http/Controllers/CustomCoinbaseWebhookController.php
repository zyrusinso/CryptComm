<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Shakurov\Coinbase\CoinbaseWebhookController;

class CustomCoinbaseWebhookController extends CoinbaseWebhookController
{
    public function handleWebhook(Request $request)
    {
        // Custom webhook handling logic
        // ...

        // Call parent method to handle Coinbase Commerce events
        return parent::handleWebhook($request);
    }
}
